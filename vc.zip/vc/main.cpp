/*
 * main.cpp
 *
 *  Created on: 12 01, 2021
 *      Author: liyanlong
 */
#include <iostream>
#include <opencv2/highgui.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>

int main(int argc, char *argv[])
{
    std::cout << "start ...!" << std::endl;
    // cv::Mat image = cv::imread("/home/li/test.png",cv::IMREAD_UNCHANGED);
    // cv::Mat logo = cv::imread("/home/li/home.png",cv::IMREAD_UNCHANGED);
    // // add logo
    // // cv::Mat imageROI;
    // // imageROI = image(cv::Rect(10,10,logo.cols,logo.rows));
    // // logo.copyTo(imageROI);
    // cv::namedWindow("result");
    // cv::imshow("result",image);
    // cv::waitKey(10);
    
    return 0;
}

